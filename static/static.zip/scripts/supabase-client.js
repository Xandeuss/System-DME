/**
 * Configuração Central do Cliente Supabase
 * Use este cliente para todas as operações de banco de dados
 */

const SUPABASE_URL = 'https://paowmuuomtqoxjxmmczu.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBhb3dtdXVvbXRxb3hqeG1tY3p1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMyMjg5NjksImV4cCI6MjA4ODgwNDk2OX0.qqKSLr98S32fAVhlT8Z-O7bWve1hVAShGz3JFEGK6cM';

// Inicializa o cliente Supabase
const supabase = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

console.log('Supabase: Cliente inicializado para o projeto DME-System');
